import ChangePasswordContainer from './ChangePasswordContainer';
export default ChangePasswordContainer;
