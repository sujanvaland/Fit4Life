import ForgotpassContainer from './ForgotpassContainer';
export default ForgotpassContainer;
