import HealthProfileContainer from './HealthProfileContainer';
export default HealthProfileContainer;
