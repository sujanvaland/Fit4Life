import PersonalDetailContainer from './PersonalDetailContainer';
export default PersonalDetailContainer;
