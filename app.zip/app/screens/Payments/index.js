import PaymentsContainer from './PaymentsContainer';
export default PaymentsContainer;
